
using Monocle;

namespace Celeste.Mod.auspicioushelper;
public class ChannelTracker : Component{
  public ChannelTracker():base(true, false){
    
  }
}